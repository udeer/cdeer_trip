<?php
/*
* WordPress REST API For MinAPP 
*/
if ( !defined( 'ABSPATH' ) ) exit;