<?php
/*
 * 
 * WP Mini Program
 * Author: 朝鹿志
 * github:  https://www.cdeer.cn
 * 基于 WordPress REST 创建小程序应用 API 数据接口。
 * 
 */
function miniprogram_api_guide(){ ?>
	<div class="wrap">
      	<div class="miniprogram-table-box">
		<table id="miniprogram_list" class="widefat striped">
		<tbody>
		<tr>
		<th colspan="2">
		<h2>WordPress 小程序</h2>
		<p>访问 <a href="https://www.cdeer.cn/" target="_blank">朝鹿志</a> <a href="https://www.cdeer.cn/" target="_blank">点击这里访问主题站</a></p>
		</th>
		</tbody>
		</table>
        <div class="card-box">
		<h2>联系我们</h2>
		<p>欢迎关注微信公众号，提供 WordPress 及小程序教程和说明。</p>
		<p>微信号：</p>
		<p><img class="card-img" src="<?php echo plugins_url(); ?>/wp-mini-program/static/5.jpg"></p>
		</div>
		</div>
		<div class="card-list">
		<div class="card-box">
		<h2>Mini Program API</h2>
		<p>WordPress Mini Program API 插件是 <a href="https://www.cdeer.cn/" target="_blank">朝鹿志</a> 基于 WP REST API 创建适合小程序的数据接口。</p>
		<p>激活使用支持 WordPress 4.9.8 , PHP 5.6 版本, 建议安装 WordPress 5.0 , PHP 7.2 以上版本。</p>
		<p><strong>注意：</strong>不能与小其他小程序 API 插件同时使用。</p>
		</div>
		<div class="card-box">
		<h2>服务器推荐</h2>
		<p>如果你需要购买优惠云服务器，希望你能使用我的推荐链接：<a href="https://static.weitimes.com/go/huawei.html" target="_blank">服务器优惠</a></p>
		<p>如果你需要购买腾讯云服务器，希望你能使用我的推荐链接：<a href="https://static.weitimes.com/go/tencent.html" target="_blank">腾讯云优惠</a></p>
		<p>如果你需要购买阿里云服务器，希望你能使用我的推荐链接：<a href="https://static.weitimes.com/go/aliyun.html" target="_blank">阿里云优惠</a></p>
		<p>如果你需要免备案云主机服务，希望你能使用我的推荐链接：<a href="https://www.vultr.com/?ref=7222201" target="_blank">Vultr Cloud Servers</a></p>
		<p>如果你需要 CDN 云加速服务，希望你能使用我的推荐链接：<a href="https://portal.qiniu.com/signup?code=1hktor67ejj2q" target="_blank">免费注册七牛云</a></p>
		</div>
		</div>
	</div>
<?php } 