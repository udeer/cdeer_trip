<?php
/*
 * include files
 */
 
if ( !defined( 'ABSPATH' ) ) exit;

include( MINI_PROGRAM_REST_API.'include/function.php' );
include( MINI_PROGRAM_REST_API.'admin/admin.php' );
include( MINI_PROGRAM_REST_API.'include/hooks.php' );
include( MINI_PROGRAM_REST_API.'include/filter.php' );
include( MINI_PROGRAM_REST_API.'include/auth.php' );
include( MINI_PROGRAM_REST_API.'include/dashboard.php' );
include( MINI_PROGRAM_REST_API.'include/custom.php' );
include( MINI_PROGRAM_REST_API.'include/notices.php' );
include( MINI_PROGRAM_REST_API.'include/subscribe.php' );